CMAKE_AUTOMOC_MOC_OPTIONS
-------------------------

Additional options for ``moc`` when using :variable:`CMAKE_AUTOMOC`.

This variable is used to initialize the :prop_tgt:`AUTOMOC_MOC_OPTIONS` property
on all the targets.  See that target property for additional information.
