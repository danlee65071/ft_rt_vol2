CMAKE_RUNTIME_OUTPUT_DIRECTORY
------------------------------

Where to put all the :ref:`RUNTIME <Runtime Output Artifacts>`
target files when built.

This variable is used to initialize the :prop_tgt:`RUNTIME_OUTPUT_DIRECTORY`
property on all the targets.  See that target property for additional
information.
