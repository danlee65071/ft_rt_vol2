CMAKE_ISPC_HEADER_DIRECTORY
----------------------------

.. versionadded:: 3.19

ISPC generated header output directory.

This variable is used to initialize the :prop_tgt:`ISPC_HEADER_DIRECTORY`
property on all the targets.  See the target property for additional
information.
