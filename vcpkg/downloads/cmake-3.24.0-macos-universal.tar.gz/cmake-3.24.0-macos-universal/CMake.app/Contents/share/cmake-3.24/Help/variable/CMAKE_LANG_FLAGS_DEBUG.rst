CMAKE_<LANG>_FLAGS_DEBUG
------------------------

This variable is the ``Debug`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>` variable.
